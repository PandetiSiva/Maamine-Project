import os
os.system("ls")
os.system("massmine --task=twitter-search --query=love --count=100 | jsan --output=mydata.csv")