<<<<<<< HEAD
# Massmine-for-the-Masses
Description of the project

Massmine-for-the-Masses is an open-source, proof of concept tool. It extends the functionality of the big data gathering tool Massmine which is a command-line interface. Massmine-for-the-Masses has a graphical user interface that allows users to see data being collected and view it in real-time, from social media platforms and Wikipedia as well. The data will also be presented in a simple user interface to allow for basic analysis without the user ever having to directly interact with it. This is an improvement of the existing project(https://github.com/JoshCMoore/Massmine-for-the-Masses and https://github.com/gowthamichinta/Massmine-for-the-Masses.git) where all the web pages are redesigned to enhance the user experience and offer smooth navigation throughout its design.

Installation

Below link includes the step-by-step instructions and requirements for installing this project https://github.com/JoshCMoore/Massmine-for-the-Masses/blob/master/documentation/UserManual.pdf

Team Members: Anusha Vanama, Gowthami Chinta, Siva Prasad Pandeti, Andy.

Instructor: Dr. Somya Mohanty
=======
## Massmine-For-The-Masses

### Massmine-For-The-Masses is an open-source, proof of concept tool. It extends the functionality of Massmine, a command-line interface which is a data gathering tool. This Massmine-For-The-Masses has a graphical user interface which allows users to see the data being collected from different platforms like Twitter, Tumblr. The collected data will also be presented in a simple user interface to allow for basic analysis. This project is an improvement of the existing project(https://github.com/AnushaVanama/Massmine-for-the-Masses) where all web pages are redisigned  and rearranged to enhance the user experience and offer smooth navigation throughout its design.

### Team Members
#### 1. Sadhana Thummalapenta
#### 2. Gowthami Chinta



```python

```


```python

```
>>>>>>> cb9b0df (changes added)
